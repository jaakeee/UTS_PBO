import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main {
    private JFrame frame;  
    private JTextField tfAngka1, tfAngka2, tfHasil;  
    private JButton btnTambah, btnKurang, btnKali, btnBagi, btnUlang;  
    private JLabel lblStatus;  
    private Kalkulator kalkulator;  

    public Main() {
        frame = new JFrame("Kalkulator Sederhana");
        frame.setSize(400, 500);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setLayout(new FlowLayout());  
        frame.setLocationRelativeTo(null);

        kalkulator = new Kalkulator(0, 0);  

        // Input Angka 1
        JLabel labelAngka1 = new JLabel("Angka 1:");
        tfAngka1 = new JTextField(10);  
        frame.add(labelAngka1);  
        frame.add(tfAngka1);

        // Input Angka 2
        JLabel labelAngka2 = new JLabel("Angka 2:");
        tfAngka2 = new JTextField(10);  
        frame.add(labelAngka2);  
        frame.add(tfAngka2);

        // Panel Tombol Operasi
        JPanel panelTombol = new JPanel();
        panelTombol.setLayout(new FlowLayout());  
        btnTambah = new JButton("+");
        btnKurang = new JButton("-");
        btnKali = new JButton("*");
        btnBagi = new JButton("/");
        panelTombol.add(btnTambah);  
        panelTombol.add(btnKurang);  
        panelTombol.add(btnKali);  
        panelTombol.add(btnBagi);  
        frame.add(panelTombol);  

        // Output Hasil
        JLabel labelHasil = new JLabel("Hasil:");
        tfHasil = new JTextField(15);  
        tfHasil.setEditable(false);  
        frame.add(labelHasil);  
        frame.add(tfHasil);  

        // Status Pesan
        lblStatus = new JLabel("");  
        frame.add(lblStatus);  

        // Tombol Ulang
        btnUlang = new JButton("Ulang");
        frame.add(btnUlang);  

        // Event Listener untuk Operasi
        btnTambah.addActionListener(e -> hitungOperasi("tambah"));
        btnKurang.addActionListener(e -> hitungOperasi("kurang"));
        btnKali.addActionListener(e -> hitungOperasi("kali"));
        btnBagi.addActionListener(e -> hitungOperasi("bagi"));

        // Tombol Reset
        btnUlang.addActionListener(e -> {
            tfAngka1.setText("");  
            tfAngka2.setText("");  
            tfHasil.setText("");   
            lblStatus.setText(""); 
        });

        frame.setVisible(true);  
    }

    // Method untuk perhitungan berdasarkan operasi yang dipilih
    private void hitungOperasi(String operasi) {
        try {
            double angka1 = Double.parseDouble(tfAngka1.getText());
            double angka2 = Double.parseDouble(tfAngka2.getText());

            kalkulator.setAngka1(angka1);
            kalkulator.setAngka2(angka2);

            switch (operasi) {
                case "tambah": kalkulator.tambah(); break;
                case "kurang": kalkulator.kurang(); break;
                case "kali": kalkulator.kali(); break;
                case "bagi": kalkulator.bagi(); break;
            }

            tfHasil.setText(String.format("%.2f", kalkulator.getHasil()));
            lblStatus.setText("Operasi berhasil!");  
        } catch (NumberFormatException ex) {
            lblStatus.setText("Input tidak valid. Masukkan angka.");
        } catch (ArithmeticException ex) {
            lblStatus.setText(ex.getMessage());
        }
    }

    // Fungsi utama untuk menjalankan kalkulator
    public static void main(String[] args) {
        new Main();  
    }
}
