public class Kalkulator {
    private double angka1;
    private double angka2;
    private double hasil;

    // Konstruktor
    public Kalkulator(double angka1, double angka2) {
        this.angka1 = angka1;
        this.angka2 = angka2;
        this.hasil = 0;
    }

    // Getter dan Setter
    public double getAngka1() {
        return angka1;
    }

    public void setAngka1(double angka1) {
        this.angka1 = angka1;
    }

    public double getAngka2() {
        return angka2;
    }

    public void setAngka2(double angka2) {
        this.angka2 = angka2;
    }

    public double getHasil() {
        return hasil;
    }

    // Method untuk penjumlahan
    public void tambah() {
        hasil = angka1 + angka2;
    }

    // Method untuk pengurangan
    public void kurang() {
        hasil = angka1 - angka2;
    }

    // Method untuk perkalian
    public void kali() {
        hasil = angka1 * angka2;
    }

    // Method untuk pembagian
    public void bagi() {
        if (angka2 != 0) {
            hasil = angka1 / angka2;
        } else {
            throw new ArithmeticException("Pembagian dengan nol tidak diperbolehkan");
        }
    }
}
